"""
OCR API Package

This package provides a FastAPI-based OCR service using EasyOCR.
"""
from .main import app

__version__ = "1.0.0"